clear all;
clc; 
close all;

global N M H g Qsqrt  x0 P0 delta gamma  R;

nExpt = 1000;

g = 9.81;        %   gravity in m/s2

delta = 0.5;      %   sampling rate

gamma = 1.49e-4;   %decaying par. in air density

M = 10e3;

H = 1e3;

Qsqrt = zeros(3);

R = (30)^2;

N = 30/delta;

x0 = [62e3; 3400; 1e-5];

P0 = diag([(1e3)^2; (100)^2; 1e-4]);

for expt = 1:nExpt
    
    fprintf('MC Run in process = %d\n',expt);  
    
    xestArray = []; 
    
    x = [61e3; 3048; 4.49e-4];
    
    for k = 1:N
        
        x = StateEq(x)+ Qsqrt*randn(3,1);
        
        z = MstEq(x)+ sqrt(R)*randn; 
        
        xArray(:,k) = x;
        
        zArray(:,k) = z;
          
    end;  
    
    BigxArray(:,:,expt) =  xArray;
    
    BigzArray(:,:,expt) =  zArray;  
    
     
 
    
end;    %end of expts

save simuData;

  
%%%========================================================================

figure;
plot([delta:delta:N*delta],xArray(1,:)/1e3,'r');
grid on;
xlabel('Time (s)','fontsize',14);
ylabel('Altitude (km)','fontsize',14);
hold off;

figure;
plot([delta:delta:N*delta],xArray(2,:),'r');
grid on;
hold on;
xlabel('Time (s)','fontsize',14);
ylabel('Velocity (m/s)','fontsize',14);
hold off;

%%%========================================================================

% rho_0 = 1.754;  %   prop. constant in air density
