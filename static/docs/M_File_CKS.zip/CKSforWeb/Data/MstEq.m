function hOut = MstEq(x)

global M H;

hOut = sqrt(M^2 +(x(1,:)-H).^2);
