function Xout = StateEq(X)

global delta gamma  g;

n = size(X,2);

Xout = X + delta*[-X(2,:); -exp(-gamma*X(1,:)).*(X(2,:).^2).*X(3,:)+g; zeros(1,n)];


