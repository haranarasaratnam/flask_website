
function [xS,Ps] = SCKS(xF,SF)

global nx N Qsqrt;

xS(:,N) = xF(:,N);

SS(:,:,N) = SF(:,:,N);

for k = (N-1):-1:1    
  
    [xk1k,Sk1k,X,Xpred] = CKS_Predict(xF(:,k),SF(:,:,k));

    [foo,S] = qr([Xpred Qsqrt; X zeros(nx,nx)]',0);

    S = S';

    A = S(1:nx,1:nx);

    B = S(nx+1:end,1:nx);

    C = S(nx+1:end,nx+1:end);

    G = B/A;

    xS(:,k) = xF(:,k) + G*( xS(:,k+1) - xk1k );

    [foo,Stmp] = qr([ C  G*SS(:,:,k+1)]',0);

    SS(:,:,k) = Stmp';

    Ps(:,:,k) = SS(:,:,k)*SS(:,:,k)';

 
end; 
    
Ps(:,:,N) = SS(:,:,N)*SS(:,:,N)';

