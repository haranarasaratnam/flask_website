
%%%========================================================================
%%% This code implements the FI-CKS (Fixed interval Cubature Kalman Smoother)
%%% for tracking a ballistic target. For more details, please refer to I.
%%% Arasaratnam et al. 
%%% "Cubature Kalman Smoothers", submitted for possible publication in
%%% Automatica
%%%========================================================================

clear all;
clc; 
close all;

global nx nz N x0 P0 QPtArray wPtArray nPts;

load simuData;  

nx = 3;   % state vector dimension

nz = 1;   % meas. vector dimension

[QPtArray,wPtArray,nPts] = findCubaturePts(nx);

MSE = zeros(nx,N);
MSEsmooth = zeros(nx,N);

PsArray = zeros(nx,nx,N);

tic;

for expt = 1:nExpt
    
    fprintf('MC Run in process = %d\n',expt);  
    
    xArray = BigxArray(:,:,expt);
    zArray = BigzArray(:,:,expt);
    
    xestArray = []; 
    
    xkk = x0; 
    
    Skk = sqrt(P0);    
 
    [xfiltArray, SfiltArray] = SCKF(xkk,Skk,zArray);
   
    [xsmoothArray,Ps] = SCKS(xfiltArray,SfiltArray);
    
    MSE = MSE + (xArray - xfiltArray).^2;         
       
    MSEsmooth = MSEsmooth + (xArray - xsmoothArray).^2; 
    
end;    %end of expts

MSE = MSE/nExpt;

RMSE = MSE.^(0.5);

RMSE_CKF = RMSE;

%Accumulative RMSE
ARMSE = sqrt(mean(MSE,2))

MSEsmooth = MSEsmooth/nExpt;

ARMSEsmooth = sqrt(mean(MSEsmooth,2))

RMSEsmooth = MSEsmooth.^(0.5);

RMSE_FI_CKS = RMSEsmooth;


%%%=======================================================================
%%% Plotting
%%%======================================================================

figure;
xax = [0.5:0.5:30];
plot(xax,RMSE_CKF(1,:),'r--','linewidth',2.5);
hold on;
plot(xax,RMSE_FI_CKS(1,:),'b-','linewidth',2.5);
ylabel('RMSE-Altitude','fontsize',14);
xlabel('Time (s)','fontsize',14);
grid on;
ylim([5 30])
legend('CKF','FI-CKS',4);

figure;
plot(xax,RMSE_CKF(2,:),'r--','linewidth',2.5);
hold on;
plot(xax,RMSE_FI_CKS(2,:),'b-','linewidth',2.5);
ylabel('RMSE-Velocity','fontsize',14);
xlabel('Time (s)','fontsize',14);
grid on;
ylim([0.5 5]);
legend('CKF','FI-CKS',1);

figure;
plot(xax,RMSE_CKF(3,:),'r--','linewidth',2.5);
hold on;
plot(xax,RMSE_FI_CKS(3,:),'b-','linewidth',2.5);
ylabel('RMSE-Ballistic Coef.','fontsize',14);
xlabel('Time (s)','fontsize',14);
grid on;
legend('CKF','FI-CKS',1);
ylim([ 1e-6 1e-5]);

