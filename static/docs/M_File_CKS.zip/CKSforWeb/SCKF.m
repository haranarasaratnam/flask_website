
function [xestArray, SArray] = SCKF(xkk,Skk,zArray)

global N;

for k = 1:N   
 
   [xkk1,Skk1] = Predict(xkk,Skk);
       
   [xkk,Skk] = Update(xkk1,Skk1,zArray(:,k));
       
   xestArray(:,k) = xkk;

   SArray(:,:,k) = Skk;
   
end;
        