function [xkk1,Skk1,X,Xpred] = CKS_Predict(xkk,Skk)

global Qsqrt QPtArray nPts;

Xi = repmat(xkk,1,nPts) + Skk*QPtArray;

Xi_pred = StateEq(Xi);

xkk1 = sum(Xi_pred,2)/nPts; 

X = (Xi-repmat(xkk,1,nPts))/sqrt(nPts);

Xpred = (Xi_pred-repmat(xkk1,1,nPts))/sqrt(nPts);

[foo,Skk1] = qr([ Xpred Qsqrt]',0);

Skk1 = Skk1'; 





