
%%%========================================================================
%%% Code used to obtain results reported in  I. Arasaratnam et al.
%%% Cubature Kalman Filtering for Continuous-Discrete Dynamic 
%%% Systems: Theory & Simulations, IEEE Trans. Signal Processing, 
%%% vol. 58, no. 10, pp. 1-17, Oct. 2010 For varaible definition, please 
%%% refer tothis paper
%%% Author Dr. I. Arasaratnam 
%%% http://grads.ece.mcmaster.ca/~aienkaran/
%%%========================================================================

clear all;
clc; 
close all;

global s M T delta QPtArray wPtArray nPts;

load simuData;

[QPtArray,wPtArray,nPts] = findCubaturePts(7);

tic;

timewdw = [1:floor(60/T)];

armse_pos = [];
armse_vel = [];
armse_omg = [];

divArray = [];

Mast = 1; % M-asteric refers to a specific M for which we draw plots

for M = 1:7
    
    delta = T/M;
    
    mse = zeros(7,N);

    fprintf('M in process = %d\n',M);      fprintf('================\n');  

    divcount = 0;

    for expt = 1:nExpt
    
        fprintf('MC Run in process = %d\n',expt);  
    
        xArray = BigxArray(:,:,expt);
        zArray = BigzArray(:,:,expt);
        
        %For initizalization with two point method
        Z0 = zArray(:,1:2);
    
        [xkk, Skk] = initialize_track(Z0(:,1),Z0(:,2),s);
    
        xestArray = zeros(7,N);   
        
        tmpmse = zeros(7,N);
    
        for k = 3:N
        
            [xkk1,Skk1] = Predict(xkk,Skk,M);

            [xkk,Skk] = Update(xkk1,Skk1,zArray(:,k));        
       
            err2 = (xArray(:,k) - xkk).^2;      %error-squared
            
            if sqrt(err2(1)+err2(3)+err2(5)) > 500
                
                tmpmse = zeros(7,N);
                
                divcount = divcount+1;          %divergence counter
                
                break;
                
            end;
       
            tmpmse(:,k) =  err2; 
        
            xestArray(:,k) = xkk;

        end;    %time-step
    
        xArray(:,timewdw) = [];
    
        xestArray(:,timewdw)=[];    
        mse = mse + tmpmse;

    end;    %expts 
    
    divArray = [divArray divcount];

    mse(:,timewdw) = [];

    mse = mse/(nExpt-divcount);

    mse_pos = sum(mse([1,3,5],:));
    armse_pos = [ armse_pos sqrt(mean(mse_pos))];

    mse_vel = sum(mse([2,4,6],:));
    armse_vel = [armse_vel sqrt(mean(mse_vel))];

    mse_omg = mse(7,:);
    armse_omg = [armse_omg 180/pi*sqrt(mean(mse_omg))];

    if (M == Mast)
    
        rmse = mse.^(0.5);
    
        rmseast_pos = sqrt(rmse(1,:).^2 + rmse(3,:).^2+ rmse(5,:).^2);
    
        rmseast_vel = sqrt(rmse(2,:).^2 + rmse(4,:).^2+ rmse(6,:).^2);
    
        rmseast_omg = 180/pi*rmse(7,:);
 end;

end; % M

armse_CRCKF = [armse_pos;armse_vel;armse_omg];
ndiv_CRCKF = divArray;

%%%%%%%%%%%%%%%%%% RMSE plots %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure;
plot(xArray(1,:),xArray(3,:),'r');
grid on;
hold on;
plot(xestArray(1,:),xestArray(3,:),'b');
xlabel('Time (s)','fontsize',14);
% legend('True Trajectory','Target Trajectory');
hold off;


figure;
subplot(3,1,1);
plot(rmseast_pos,'r','LineWidth',3);
ylabel('Position (m)','fontsize',16);
xlabel('Time (sec)');
grid on;

subplot(3,1,2);
plot(rmseast_vel,'r','LineWidth',3);
ylabel('Velocity (m/s)','fontsize',16);
xlabel('Time (sec)');
grid on;

subplot(3,1,3);
plot(rmseast_omg,'r','LineWidth',3);
ylabel('Turn Rate (m/s)','fontsize',16);
xlabel('Time (sec)');
grid on;

figure;
subplot(3,1,1);
plot(armse_pos);
subplot(3,1,2);
plot(armse_vel);
subplot(3,1,3);
plot(armse_omg);

