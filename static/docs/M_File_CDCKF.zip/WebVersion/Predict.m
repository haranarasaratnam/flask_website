function [xkk1,Skk1] = Predict(xkk,Skk,M)

global sig1 sig2 T Qsqrt QPtArray nPts;

Xi = repmat(xkk,1,nPts) + Skk*QPtArray;

Xi = StateEq_filt(Xi,M);

xkk1 = sum(Xi,2)/nPts; 

X = (Xi-repmat(xkk1,1,nPts))/sqrt(nPts);

L2 = sig1*[1 0 0 xkk(7) 0 0 0]';

L4 = sig1*[0 -xkk(7) 1 0 0 0 0]';

L6 = [0 0 0  0 sig1 0 0]';

L7 = sig2*[0 -xkk(4) 0 xkk(2) 0 0 0]';

L = [zeros(7,1) L2 zeros(7,1) L4 zeros(7,1) L6 L7];

[foo,Skk1] = qr([ X sqrt(T)*(Qsqrt+0.5*T*L)  sqrt(T/3)*0.5*T*L]',0);

Skk1 = Skk1'; 

