function x = StateEq(x)

global M sqrtcov_pNoise sig1 sig2  delta;


for j = 1:M   
    
    e = sqrtcov_pNoise*randn(14,1);            
   
    f = [x(2)  -x(7)*x(4)  x(4) x(7)*x(2) x(6) 0 0]';

    L0 = x(7)*[-x(4) -x(7)*x(2) x(2) -x(7)*x(4) 0 0 0]';

    L_2 = sig1*[1 0 0 x(7) 0 0 0]';

    L_4 = sig1*[0 -x(7) 1 0 0 0 0]';
    
    L_6 = [0 0 0  0 sig1 0 0]';

    L_7 = sig2*[0 -x(4) 0 x(2) 0 0 0]';

    L = [zeros(7,1) L_2 zeros(7,1) L_4  zeros(7,1) L_6 L_7];

    x = x + delta*f + 0.5*delta^2*L0+ [0 sig1*e(2) 0 sig1*e(4) 0 sig1*x(6) sig2*e(7)]' + L*e(8:14);

end;



