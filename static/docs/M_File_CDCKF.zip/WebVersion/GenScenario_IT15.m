clear all;
clc; 
close all;

global  M sqrtcov_pNoise x0 delta  sig1 sig2 Qsqrt  Rsqrt; 

omg0 = 4.5;

T = 6;

nExpt = 50;          

N = floor(210/T);

s = [1500 10 0]';

sig1 = sqrt(2e-1);

sig2 = sqrt(5e-7);

Qsqrt = diag([0 sig1 0 sig1 0 sig1 sig2]);

M = 100;

Rsqrt = diag([50 0.1*pi/180 0.1*pi/180]);

delta = T/M;          % Sampling time step

%%========================================================================
%%% filter initialization 
%%%========================================================================

x0 = [1e3 0 2650 150  200  0 omg0*pi/180]';

%%%=======================================================================

noiseCov = zeros(14);
noiseCov(1:7,1:7) = delta*eye(7);
noiseCov(8:14,8:14) = delta^3/3*eye(7);
noiseCov(1:7,8:14) = 0.5*delta^2*eye(7);
noiseCov(8:14,1:7) = 0.5*delta^2*eye(7);
            
[U,D,V] = svd(noiseCov);
sqrtcov_pNoise = U*sqrt(D);

%%%=======================================================================

for expt = 1:nExpt

    fprintf('MC Run in process = %d\n',expt);

    X = x0;       %Initial state

    xArray = [];    zArray = [];

    for i = 1:N

        X = StateEq(X);

        xArray = [xArray X];

        Z = MstEq(X,s)+ Rsqrt*randn(3,1);

        zArray = [zArray Z];


    end;    % expt

    BigxArray(:,:,expt) =  xArray;

    BigzArray(:,:,expt) =  zArray;


end;

save simuData;
  
%%%========================================================================

figure;
subplot(2,1,1);
plot([T:T:N*T],xArray(1,:),'r');
ylabel('x-Pos. (m)','fontsize',14);
grid on;
subplot(2,1,2);
plot([T:T:N*T],xArray(3,:),'r');
grid on;
xlabel('Time (s)','fontsize',14);
ylabel('Y-Pos. (m)','fontsize',14);
hold off;



figure;
subplot(2,1,1);
plot([T:T:N*T],xArray(2,:),'r');
ylabel('x-Vel. (m/s)','fontsize',14);
grid on;
subplot(2,1,2);
plot([T:T:N*T],xArray(4,:),'r');
grid on;
xlabel('Time (s)','fontsize',14);
ylabel('Y-Vel. (m/s)','fontsize',14);
hold off;


figure;
plot([T:T:N*T],xArray(7,:)*180/pi,'r');
ylabel('x-Vel. (m/s)','fontsize',14);
grid on;

figure;
plot(xArray(1,:),xArray(3,:),'r');
grid on;
xlabel('Time (s)','fontsize',14);
ylabel('Altitude (km)','fontsize',14);
% legend('True Trajectory','Target Trajectory');
hold off;

