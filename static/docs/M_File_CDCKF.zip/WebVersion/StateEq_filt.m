function xOut = StateEq_filt(X,M)

global delta;

L = size(X,2);

for i = 1:L

    x = X(:,i);

    for m = 1:M

        f = [x(2)  -x(7)*x(4)  x(4) x(7)*x(2) x(6) 0 0]';

        L0 = x(7)*[-x(4) -x(7)*x(2) x(2) -x(7)*x(4) 0 0 0]';

        x = x+ delta*f + 0.5*delta^2*L0;

    end;

    xOut(:,i) = x;

end;


