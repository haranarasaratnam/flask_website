function z = MstEq(x,s)

ran = sqrt(  (x(1,:)-s(1)).^2 + (x(3,:)-s(2)).^2 + (x(5,:)-s(3)).^2);

azi =  atan2( (x(3,:)-s(2)), (x(1,:)-s(1)) );

ele = atan2( (x(5,:)-s(3)), sqrt(  (x(1,:)-s(1)).^2 + (x(3,:)-s(2)).^2 ));

z = [ran; azi; ele];

