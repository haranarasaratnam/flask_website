function [x, Psqrt] = initialize_track(z1,z2,s)

global T Rsqrt;

x1 = z1(1)*[cos(z1(2)) sin(z1(2))]';
x1 = s([1 2])+x1;

x2 = z2(1)*[cos(z2(2)) sin(z2(2))]';
x2 = s([1 2])+x2;

x = [x1(1) (x2(1) - x1(1))/T x1(2) (x2(2) - x1(2))/T]';

x = [x; 150; 0; (3*pi/180)];

R = Rsqrt*Rsqrt';

R11 = z1(1)^2*R(2,2)*(sin(z1(2)))^2+R(1,1)*(cos(z1(2)))^2;
R22 = z1(1)^2*R(2,2)*(cos(z1(2)))^2 + R(1,1)*(sin(z1(2)))^2;
R12 = ( R(1,1)- z1(1)^2*R(2,2) )*sin(z1(2))*cos(z1(2));

P = [R11 0 R12 0 ;
     0 (50)^2 0 0 ;
     R12 0 R22 0 ;
     0 0 0 50^2];
    
[U,D,V] = svd(P);
    
Psqrt = U*sqrt(D);

tmp = diag([100 50  (1*pi/180)]);
    
Psqrt = [Psqrt zeros(4,3); zeros(3,4) tmp];
    
    
    
    

