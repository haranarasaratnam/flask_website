function [X,Z]=simulate_flight(X,model,v1_sigma,v2_sigma,omega)

global nz T Rsqrt;

if (model ==1)
    X(5,:) = [];
    F = [1 T 0 0; 0 1 0  0; 0 0 1 T; 0 0 0 1];

    v1 = [T^2/2 0; T  0; 0 T^2/2; 0 T ]*(v1_sigma*randn(2,1));

    X = F*X + v1;

    X = [X ; 0];
else

    F = [1 sin(omega*T)/omega  0  -(1- (cos(omega*T)))/omega 0;
        0 cos(omega*T) 0 -sin(omega*T) 0;
        0 (1- (cos(omega*T)))/omega  1  sin(omega*T)/omega 0;
        0  sin(omega*T) 0 cos(omega*T) 0;
        0 0 0 0 1];

    v2 = [T^2/2 0 0;  T 0 0;  0 T^2/2 0; 0 T 0; 0 0 T]*[v1_sigma.*randn(2,1);v2_sigma*randn];

    X = F*X + v2;

end;

Z = MstEq(X)+ Rsqrt*randn(nz,1);
    
