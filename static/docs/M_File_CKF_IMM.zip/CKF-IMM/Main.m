close all;
clear all;
clc;

global nz s T Rsqrt v1_sigma v2_sigma;

omega1 = pi/180; % turn rate1
omega2 = -3*pi/180; % turn rate2

s = [2e4 2e4]';  % radar position

Rsqrt = diag([10  0.1*pi/180]);
nz = 2;

T = 5;

k_max = 100;
turn1_onset = 26;
turn1_terminate = 43;
turn2_onset = 68;
turn2_terminate = 73;

%quatities associate. state eqn
v1_sigma = 0.01;     %std. dev associated with linear part in process eqn.
v2_sigma = 1e-6;      %std dev ass. with turning motion

Evel_initial = 120;
Nvel_initial = 0;
X = [1e4; Evel_initial; 3.5e4; Nvel_initial; 0];

xArray = [];
xestArray = [];
ZArray = [];
muArray = [];

for k=1:k_max

    if (k>=1 && k <(turn1_onset)) || (k > turn1_terminate && k <turn2_onset)|| (k > turn2_terminate)
        model = 1;
        [X,Z]=  simulate_flight(X,model,v1_sigma);

    elseif (k > (turn1_onset- 1) && k <= turn1_terminate)
        model = 2;
        omega = omega1;
        if (k==turn1_onset)
            X(5) = omega;
        end;
        [X,Z]=  simulate_flight(X,model,v1_sigma,v2_sigma,omega);


    else
        model = 2;
        omega = omega2;
        if (k==turn2_onset)
            X(5) = omega;
        end;
        [X,Z]=  simulate_flight(X,model,v1_sigma,v2_sigma,omega);

    end ;

    [xhat,Phat,mu]= IMM(Z);

    xArray = [xArray X];
    ZArray = [ZArray Z];
    xestArray = [xestArray xhat];
    muArray = [muArray  mu];

end;

plot(xArray(1,:),xArray(3,:),'r');
axis([0 6e4 0 6.5e4]);
hold on;
plot(xestArray(1,:),xestArray(3,:),'k:');
plot(s(1),s(2),'*');
xlabel('x(m)','fontsize',16);
ylabel('y(m)','fontsize',16);
legend('True Trajectory','Target Trajectory',4);
hold off;

figure;
t_muArray = zeros(1,length(muArray));
for k=1:k_max
    if xArray(5,k) == 0
        t_muArray(1,k)=1;
    else
        t_muArray(1,k) = 0;
    end;
end;
plot(t_muArray,'r');
hold on;
plot(muArray(1,:),'b:');
title('\mu');
axis([0 k_max -0.1 1.1 ]);
ylabel('Mode:1 probability','fontsize',16);
legend('Ideal Mode Probability','IMM-Estimate',3);
hold off;


figure;
pos_error = sqrt((xArray(1,:)-xestArray(1,:)).^2+(xArray(3,:)-xestArray(3,:)).^2);
plot(pos_error);
ylabel('RMS Position Error (m)','fontsize',16);
%title('Position-error');

figure;
Etavel_error = sqrt((xArray(2,:)-xestArray(2,:)).^2+(xArray(4,:)-xestArray(4,:)).^2);
plot(Etavel_error);
ylabel('RMS Velocity Error (m/s)','fontsize',16);
%title('Etavel-error');




  

      