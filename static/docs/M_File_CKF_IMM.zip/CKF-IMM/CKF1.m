function [xkk,Skk,LH]= CKF1(xkk,Skk,z)

global nz T Rsqrt;

xkk(5,:) = [];
Skk(5,:) = [];
Skk(:,5)=[];

%------------------------------------------------------------------------
%predict
%-------------------------------------------------------------------------

G1 = [T^2/2 0 ; T 0 ; 0 T^2/2 ; 0 T ];

Q1sqrt = G1*sqrt(diag([0.1^2 ; 0.1^2 ]));

F = [1 T 0 0;
    0 1 0  0;
    0 0 1 T;
    0 0 0 1];


xkk1 = F*xkk ;

[foo,S]= qr([F*Skk Q1sqrt]',0);
Skk1 = S';


%%%========================================================================
%%% Genrate a set of Cubature Points
%%%========================================================================

nx = 4; % state vector dimension

nz = 2;

nPts = 2*nx;        % No. of Cubature Points

CPtArray = sqrt(nPts/2)*[eye(nx) -eye(nx)];

%------------------------------------------------------------------------
%update
%-------------------------------------------------------------------------

Xi =  repmat(xkk1,1,nPts) + Skk1*CPtArray;

Zi = MstEq(Xi);

zkk1 = sum(Zi,2)/nPts;   % predicted Measurement

X = (Xi-repmat(xkk1,1,nPts))/sqrt(nPts);

Z = (Zi-repmat(zkk1,1,nPts))/sqrt(nPts);

[foo,S] = qr([Z Rsqrt; X zeros(nx,nz)]',0);

S = S';

A = S(1:nz,1:nz);   % Square-root Innovations Covariance

B = S(nz+1:end,1:nz);

C = S(nz+1:end,nz+1:end);

G = B/A;          % Cubature Kalman Gain

Skk = C;

inn = (z-zkk1);  %innovation

xkk = xkk1 + G*inn;

nis = (A\inn)'*(A\inn);    % nis := Nomalized Innovations Squared

LH = 1/sqrt((det(2*pi*A*A')))*exp(-0.5*nis) + 1e-99; %LH:=likelihood

%-------------------------------------------------------------------------
%For the  purpose of output
%-------------------------------------------------------------------------

xkk =  [xkk;0];
Skk = [Skk zeros(4,1);zeros(1,5)];
