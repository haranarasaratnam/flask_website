function z = MstEq(x)

global s;

r = sqrt(  (x(1,:)-s(1)).^2 + (x(3,:)-s(2)).^2 );

bear = atan2((x(3,:)-s(2)),(x(1,:)-s(1))) ;

z = [ r;bear];