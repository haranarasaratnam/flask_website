
function [xkk,Skk,LH]= CKF2(xkk,Skk,z)

global nz T Rsqrt;

%------------------------------------------------------------------------
%predict
%-------------------------------------------------------------------------

nx = 5;
nPts = 2*nx;        % No. of Cubature Points
CPtArray = sqrt(nPts/2)*[eye(nx) -eye(nx)];

G2 = [T^2/2 0 0; T 0 0; 0 T^2/2 0; 0 T 0; 0 0 T];

Q2sqrt = G2*sqrt(diag([0.1^2 ; 0.1^2 ;1e-6]));

% Q2sqrt = G2*diag([v1_sigma  v1_sigma v2_sigma]);


Xi = repmat(xkk,1,nPts) + Skk*CPtArray;

Xi = StateEq(Xi);

xkk1 = sum(Xi,2)/nPts;

X = (Xi-repmat(xkk1,1,nPts))/sqrt(nPts);

[foo,Skk1] = qr([ X Q2sqrt]',0);

Skk1 = Skk1';

%------------------------------------------------------------------------
%update
%-------------------------------------------------------------------------

Xi =  repmat(xkk1,1,nPts) + Skk1*CPtArray;

Zi = MstEq(Xi);

zkk1 = sum(Zi,2)/nPts;   % predicted Measurement

X = (Xi-repmat(xkk1,1,nPts))/sqrt(nPts);

Z = (Zi-repmat(zkk1,1,nPts))/sqrt(nPts);

[foo,S] = qr([Z Rsqrt; X zeros(nx,nz)]',0);

S = S';

A = S(1:nz,1:nz);   % Square-root Innovations Covariance

B = S(nz+1:end,1:nz);

C = S(nz+1:end,nz+1:end);

G = B/A;          % Cubature Kalman Gain

Skk = C;

inn = (z-zkk1);

xkk = xkk1 + G*inn;

nis = (A\inn)'*(A\inn);    % nis := Nomalized Innovations Squared

LH = 1/sqrt((det(2*pi*A*A')))*exp(-0.5*nis) + 1e-99; %LH:=likelihood

function Xout = StateEq(X)

global T;

L = size(X,2);

for i=1:L

    x = X(:,i);

    Omg = x(5);

    if (abs(Omg)<realmin)

        F = [1 T 0 0 0
            0 1 0 0 0
            0 0 1 T 0
            0 0 0 1 0
            0 0 0 0 1];


    else

        F= [1 sin(Omg*T)/Omg 0 -(1- cos(Omg*T))/Omg 0;
            0 cos(Omg*T) 0 -sin(Omg*T) 0;
            0  (1- cos(Omg*T))/Omg 1  sin(Omg*T)/Omg 0;
            0  sin(Omg*T) 0 cos(Omg*T) 0;
            0 0 0 0 1];

    end

    Xout(:,i) = F*x;

end;

