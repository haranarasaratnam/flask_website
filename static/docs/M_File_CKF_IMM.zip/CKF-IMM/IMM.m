function [xkk,Skk,MU]= IMM(z)

%mu - Col. vector for  mode probabilites

persistent XKK SKK mu;

%------------------------------------------------------------------------

%initialize the track
if (isempty(XKK))
    %     xkk = [z(1)*cos(z(3)); 125; z(1)*sin(z(3)); 5; 0];

    xkk = [1e4; 120; 3.5e4; 0; 0];

    Skk = sqrt(diag([1000^2; 10^2 ; 1000^2; 10^2; 1e-6]));

    XKK = [xkk  xkk];

    SKK(:,:,1) = Skk;
    SKK(:,:,2) = Skk;

    mu = [0.5; 0.5];
end;

%------------------------------------------------------------------------
%calculate the mixing prob., mix

%Define the MTP
p_ij = [0.95  0.05; 0.1 0.9];

cbar = p_ij'*mu;

for j=1:2
    for i=1:2
        mix(i,j)=p_ij(i,j)*mu(i)/cbar(j);
    end;
end;

%--------------------------------------------------------------------------

%Mixing

xMix = zeros(5,2);
for j=1:2
    for i=1:2
        xMix(:,j) = xMix(:,j) + mix(i,j)*XKK(:,i);
    end;

end;

X = [XKK-repmat(xMix(:,1),1,2)]*diag(sqrt(mix(:,1)));

[foo,S] = qr([sqrt(mix(1,1))*SKK(:,:,1)  sqrt(mix(2,1))*SKK(:,:,2) X ]',0);

SMix(:,:,1) = S';

X = [XKK-repmat(xMix(:,2),1,2)]*diag(sqrt(mix(:,2)));

[foo,S] = qr([sqrt(mix(1,2))*SKK(:,:,1)  sqrt(mix(2,2))*SKK(:,:,2) X ]',0);

SMix(:,:,2) = S';

%-------------------------------------------------------------------------

%Mode matched filtering

[XKK(:,1),SKK(:,:,1),LH(1)]= CKF1(xMix(:,1),SMix(:,:,1),z);

[XKK(:,2),SKK(:,:,2),LH(2)]= CKF2(xMix(:,2),SMix(:,:,2),z);

%------------------------------------------------------------------------

%Mode prob. update
mu = LH'.*cbar;
mu = mu/sum(mu);
MU = mu;

%-----------------------------------------------------------------------
%Estimate xkk and Skk for output purpose

xkk = XKK*mu;

X = [XKK-repmat(xkk,1,2)]*diag(sqrt(mu));

[foo,S]  = qr([mu(1)*SKK(:,:,1) mu(2)*SKK(:,:,2) X]',0);

Skk = S';



